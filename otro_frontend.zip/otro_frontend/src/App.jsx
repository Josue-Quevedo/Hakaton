import  Home  from './components/Home';
import * as bootstrap from 'bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
function App(){
    return(
        <div className='contanier' >
            {/* <Menu /> */}
            <Home />
            {/* <Login /> */}
        </div>
    )
}

export default App