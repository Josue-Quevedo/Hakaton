const Alumnos = () => {
  
    return (
      <section className="mt-5 text-center">
        <h1>Alumnos</h1>
        
        
      </section>
    )
  }
  
  
  export default Alumnos