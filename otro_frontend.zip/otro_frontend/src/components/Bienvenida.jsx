const Login = () => {
  
  return (
    <section className="mt-5 text-center">
      <h1>Bienvenido a Quality Earth</h1>
      
      
    </section>
  )
}


export default Login